package report.model.dao;

import java.sql.Connection;
import java.util.ArrayList;

import report.model.vo.Report;

public class ReportDao {

	public Report selectReport(Connection conn, int reportid) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<Report> selectReportAll(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

	public int insertReport(Connection conn, Report report) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateReport(Connection conn, Report report) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteReport(Connection conn, Report report) {
		// TODO Auto-generated method stub
		return 0;
	}

}
