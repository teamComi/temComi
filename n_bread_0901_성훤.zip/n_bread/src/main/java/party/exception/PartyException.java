package party.exception;

public class PartyException extends Exception{
	public PartyException(String message) {
		super(message);
	}
}
