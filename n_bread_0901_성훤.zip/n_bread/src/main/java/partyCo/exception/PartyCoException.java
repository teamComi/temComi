package partyCo.exception;

public class PartyCoException extends Exception {
	public PartyCoException(String message) {
		super(message);
	}
}
