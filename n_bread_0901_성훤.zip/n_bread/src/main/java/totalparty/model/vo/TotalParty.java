package totalparty.model.vo;

public class TotalParty implements java.io.Serializable{
    private int paNum;
    private int paMem1;
    private int paMem2;
    private int paMem3;
    private int paMem4;
    private int paMem5;
    private int paMem6;
    private int paMem7;
    private int paMem8;
    private int paMem9;
    private int paMem10;

    public TotalParty() {
		super();
	}

	public TotalParty(int paNum, int paMem1, int paMem2, int paMem3, int paMem4, int paMem5, int paMem6, int paMem7,
			int paMem8, int paMem9, int paMem10) {
		super();
		this.paNum = paNum;
		this.paMem1 = paMem1;
		this.paMem2 = paMem2;
		this.paMem3 = paMem3;
		this.paMem4 = paMem4;
		this.paMem5 = paMem5;
		this.paMem6 = paMem6;
		this.paMem7 = paMem7;
		this.paMem8 = paMem8;
		this.paMem9 = paMem9;
		this.paMem10 = paMem10;
	}

	/**
     * @return int return the paNum
     */
    public int getPaNum() {
        return paNum;
    }

    /**
     * @param paNum the paNum to set
     */
    public void setPaNum(int paNum) {
        this.paNum = paNum;
    }

    /**
     * @return int return the paMem1
     */
    public int getPaMem1() {
        return paMem1;
    }

    /**
     * @param paMem1 the paMem1 to set
     */
    public void setPaMem1(int paMem1) {
        this.paMem1 = paMem1;
    }

    /**
     * @return int return the paMem2
     */
    public int getPaMem2() {
        return paMem2;
    }

    /**
     * @param paMem2 the paMem2 to set
     */
    public void setPaMem2(int paMem2) {
        this.paMem2 = paMem2;
    }

    /**
     * @return int return the paMem3
     */
    public int getPaMem3() {
        return paMem3;
    }

    /**
     * @param paMem3 the paMem3 to set
     */
    public void setPaMem3(int paMem3) {
        this.paMem3 = paMem3;
    }

    /**
     * @return int return the paMem4
     */
    public int getPaMem4() {
        return paMem4;
    }

    /**
     * @param paMem4 the paMem4 to set
     */
    public void setPaMem4(int paMem4) {
        this.paMem4 = paMem4;
    }

    /**
     * @return int return the paMem5
     */
    public int getPaMem5() {
        return paMem5;
    }

    /**
     * @param paMem5 the paMem5 to set
     */
    public void setPaMem5(int paMem5) {
        this.paMem5 = paMem5;
    }

    /**
     * @return int return the paMem6
     */
    public int getPaMem6() {
        return paMem6;
    }

    /**
     * @param paMem6 the paMem6 to set
     */
    public void setPaMem6(int paMem6) {
        this.paMem6 = paMem6;
    }

    /**
     * @return int return the paMem7
     */
    public int getPaMem7() {
        return paMem7;
    }

    /**
     * @param paMem7 the paMem7 to set
     */
    public void setPaMem7(int paMem7) {
        this.paMem7 = paMem7;
    }

    /**
     * @return int return the paMem8
     */
    public int getPaMem8() {
        return paMem8;
    }

    /**
     * @param paMem8 the paMem8 to set
     */
    public void setPaMem8(int paMem8) {
        this.paMem8 = paMem8;
    }

    /**
     * @return int return the paMem9
     */
    public int getPaMem9() {
        return paMem9;
    }

    /**
     * @param paMem9 the paMem9 to set
     */
    public void setPaMem9(int paMem9) {
        this.paMem9 = paMem9;
    }

    /**
     * @return int return the paMem10
     */
    public int getPaMem10() {
        return paMem10;
    }

    /**
     * @param paMem10 the paMem10 to set
     */
    public void setPaMem10(int paMem10) {
        this.paMem10 = paMem10;
    }

	@Override
	public String toString() {
		return "totalparty [paNum=" + paNum + ", paMem1=" + paMem1 + ", paMem2=" + paMem2 + ", paMem3=" + paMem3
				+ ", paMem4=" + paMem4 + ", paMem5=" + paMem5 + ", paMem6=" + paMem6 + ", paMem7=" + paMem7
				+ ", paMem8=" + paMem8 + ", paMem9=" + paMem9 + ", paMem10=" + paMem10 + "]";
	}
    

}
