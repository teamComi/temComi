package noticeCo.model.dao;

import java.sql.Connection;
import java.util.ArrayList;

import noticeCo.model.vo.NoticeCo;

public class NoticeCoDao {

	public NoticeCo selectNoticeCo(Connection conn, int noticeCoid) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<NoticeCo> selectNoticeCoAll(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

	public int insertNoticeCo(Connection conn, NoticeCo noticeCo) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateNoticeCo(Connection conn, NoticeCo noticeCo) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteNoticeCo(Connection conn, NoticeCo noticeCo) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int loadNoticeCo(Connection conn, NoticeCo noticeCo) {
		// TODO Auto-generated method stub
		return 0;
	}

	public ArrayList<NoticeCo> searchNoticeCo(Connection conn, String keyword) {
		// TODO Auto-generated method stub
		return null;
	}

}
