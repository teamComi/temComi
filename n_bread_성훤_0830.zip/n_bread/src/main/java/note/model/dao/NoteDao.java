package note.model.dao;

import java.sql.Connection;
import java.util.ArrayList;

import note.model.vo.Note;

public class NoteDao {

	public Note selectMessage(Connection conn, int messageid) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<Note> selectMessageAll(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

	public int insertMessage(Connection conn, Note message) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateMessage(Connection conn, Note message) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteMessage(Connection conn, Note message) {
		// TODO Auto-generated method stub
		return 0;
	}

}
