package member.exception;

public class MemberException extends Exception {
	public MemberException(String message) {
		super(message);
	}
}
