package notice.exception;

public class NoticeException {

}
