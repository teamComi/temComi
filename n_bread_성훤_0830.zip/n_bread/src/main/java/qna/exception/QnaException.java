package qna.exception;

public class QnaException extends Exception {
	public QnaException(String message) {
		super(message);
	}
}
