package qnaCo.exception;

public class QnaCoException extends Exception {
	public QnaCoException(String message) {
		super(message);
	}
}
