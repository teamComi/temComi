package partyCh.exception;

public class PartyChException extends Exception {
	public PartyChException(String message) {
		super(message);
	}
}
