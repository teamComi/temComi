package noticeCo.exception;

public class NoticeCoException {

}
