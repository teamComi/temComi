package payment.model.dao;

import java.sql.Connection;
import java.util.ArrayList;

import payment.model.vo.Payment;

public class PaymentDao {

	public Payment selectPayment(Connection conn, int paymentid) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<Payment> selectPaymentAll(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

	public int insertPayment(Connection conn, Payment payment) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deletePayment(Connection conn, Payment payment) {
		// TODO Auto-generated method stub
		return 0;
	}

}
