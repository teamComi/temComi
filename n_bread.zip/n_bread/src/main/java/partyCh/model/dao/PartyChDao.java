package partyCh.model.dao;

import java.sql.Connection;

import partyCh.model.vo.PartyCh;

public class PartyChDao {

	public PartyCh selectPartyCh(Connection conn, int partyid) {
		// TODO Auto-generated method stub
		return null;
	}

	public int insertPartyCh(Connection conn, PartyCh partyCh) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deletePartyCh(Connection conn, PartyCh partyCh) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int loadPartyCh(Connection conn, PartyCh partyCh) {
		// TODO Auto-generated method stub
		return 0;
	}

}
