package refund.model.dao;

import java.sql.Connection;
import java.util.ArrayList;

import refund.model.vo.Refund;

public class RefundDao {

	public Refund selectRefund(Connection conn, int refundid) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<Refund> selectRefundAll(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

	public int insertRefund(Connection conn, Refund refund) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteRefund(Connection conn, Refund refund) {
		// TODO Auto-generated method stub
		return 0;
	}

}
