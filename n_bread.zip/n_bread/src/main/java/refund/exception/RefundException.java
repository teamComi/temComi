package refund.exception;

public class RefundException {

}
