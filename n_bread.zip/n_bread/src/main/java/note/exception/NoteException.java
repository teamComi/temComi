package note.exception;

public class NoteException extends Exception {
	public NoteException(String message) {
		super(message);
	}
}
